import { DynamoDB } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocument } from "@aws-sdk/lib-dynamodb";

const dynamodb = new DynamoDB();
const dynamoDBDocClient = DynamoDBDocument.from(dynamodb);

export const handler = async (event) => {
  console.log(JSON.stringify(event.body));
  let body;
  let statusCode = "200";
  const headers = {
    "Content-Type": "application/json",
  };

  const requestBody = JSON.parse(event.body);
  const { device_id, user_id } = requestBody;

  try {
    // Check if the device_id exists in the Logs table
    const logsParams = {
      TableName: "Logs",
      KeyConditionExpression: "device_id = :deviceID",
      ExpressionAttributeValues: {
        ":deviceID": device_id,
      },
    };

    const logsResult = await dynamoDBDocClient.query(logsParams);

    if (!logsResult.Items || logsResult.Items.length === 0) {
      statusCode = "404";
      body = "Device ID not found in the Logs table";
    } else {
      const logs = logsResult.Items;
      const filteredLogs = logs.filter((log) => log.user_id === user_id);
      if (filteredLogs.length === 0) {
        statusCode = "403";
        body = "Unauthorized user";
      } else {
        body = filteredLogs;
      }
    }
  } catch (err) {
    statusCode = "400";
    body = err.message;
  } finally {
    body = JSON.stringify(body);
  }

  return {
    statusCode,
    body,
    headers,
  };
};
