import { DynamoDB } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocument } from "@aws-sdk/lib-dynamodb";
import { formatISO } from "date-fns";

const dynamodb = new DynamoDB();
const dynamoDBDocClient = DynamoDBDocument.from(dynamodb);

export const handler = async (event) => {
  console.log(JSON.stringify(event.body));
  let body;
  let statusCode = "200";
  const headers = {
    "Content-Type": "application/json",
  };

  const requestBody = JSON.parse(event.body);
  const { id } = requestBody; // Extract 'id' and 'user_id' parameters

  const filterExpressions = [];
  const expressionAttributeNames = {};
  const expressionAttributeValues = {};

  if (id) {
    filterExpressions.push("contains(#id, :id)");
    expressionAttributeNames["#id"] = "id";
    expressionAttributeValues[":id"] = id;
  }

  let params = {
    TableName: "Devices",
  };

  // Check if any parameters were provided
  if (filterExpressions.length > 0) {
    params = {
      ...params,
      FilterExpression: filterExpressions.join(" AND "),
      ExpressionAttributeNames: expressionAttributeNames,
      ExpressionAttributeValues: expressionAttributeValues,
    };
  }

  try {
    const result = await dynamoDBDocClient.scan(params);
    body = result.Items;

    // Update the last_online value with today's time for each item in the result
    const updatePromises = body.map(async (item) => {
      const updateParams = {
        TableName: "Devices",
        Key: {
          id: item.id,
        },
        UpdateExpression: "SET last_online = :lastOnline",
        ExpressionAttributeValues: {
          ":lastOnline": formatISO(new Date()),
        },
        ReturnValues: "ALL_NEW",
      };

      return dynamoDBDocClient.update(updateParams);
    });

    await Promise.all(updatePromises);
  } catch (err) {
    statusCode = "400";
    body = err.message;
  } finally {
    body = JSON.stringify(body);
  }

  return {
    statusCode,
    body,
    headers,
  };
};
