import { DynamoDB } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocument } from "@aws-sdk/lib-dynamodb";

const dynamodb = new DynamoDB();
const dynamoDBDocClient = DynamoDBDocument.from(dynamodb);

export const handler = async (event) => {
  console.log(JSON.stringify(event.body));
  let body;
  let statusCode = "200";
  const headers = {
    "Content-Type": "application/json",
  };

  const requestBody = JSON.parse(event.body);
  const {
    device_id,
    user_id,
    ac_temperature,
    water_temperature,
    ac_state,
    heater_state,
    auto,
  } = requestBody;

  try {
    // Check if the device_id exists in the Devices table
    const deviceParams = {
      TableName: "Devices",
      Key: {
        id: device_id,
      },
    };

    const deviceResult = await dynamoDBDocClient.get(deviceParams);

    if (!deviceResult.Item) {
      statusCode = "404";
      body = "Device ID not found in the Devices table";
    } else {
      const { user_id: loggedUserId } = deviceResult.Item;

      if (loggedUserId !== user_id) {
        statusCode = "403";
        body = "Unauthorized user";
      } else {
        // Update the ac_temperature, water_temperature, ac_state, heater_state, and auto values in the Devices table
        const updateParams = {
          TableName: "Devices",
          Key: {
            id: device_id,
          },
          UpdateExpression:
            "SET ac_temperature = :acTemp, water_temperature = :waterTemp, ac_state = :acState, heater_state = :heaterState, auto = :autoValue",
          ExpressionAttributeValues: {
            ":acTemp": ac_temperature,
            ":waterTemp": water_temperature,
            ":acState": ac_state,
            ":heaterState": heater_state,
            ":autoValue": auto,
          },
          ReturnValues: "ALL_NEW",
        };

        const updateResult = await dynamoDBDocClient.update(updateParams);

        body = updateResult.Attributes;
      }
    }
  } catch (err) {
    statusCode = "400";
    body = err.message;
  } finally {
    body = JSON.stringify(body);
  }

  return {
    statusCode,
    body,
    headers,
  };
};
